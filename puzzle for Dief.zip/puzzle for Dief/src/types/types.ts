export interface IPicture{
    id:number,
    name:string,
    url:string,
}